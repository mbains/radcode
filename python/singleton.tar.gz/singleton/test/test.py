from singleton import Klass
print "setting value to 5"
Klass().value=5

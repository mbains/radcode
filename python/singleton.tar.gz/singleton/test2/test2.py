from singleton import Klass
print "Klass().value %d" % Klass().value

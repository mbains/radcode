#!/bin/bash
flint co-gnu3.lnt lib-stl.lnt include.lnt  main.cpp
